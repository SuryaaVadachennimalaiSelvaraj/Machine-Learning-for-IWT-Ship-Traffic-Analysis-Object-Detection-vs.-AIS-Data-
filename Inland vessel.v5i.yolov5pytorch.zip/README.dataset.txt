# Inland vessel > 2023-06-16 11:15am
https://universe.roboflow.com/thesis-sxxfi/inland-vessel

Provided by a Roboflow user
License: CC BY 4.0

